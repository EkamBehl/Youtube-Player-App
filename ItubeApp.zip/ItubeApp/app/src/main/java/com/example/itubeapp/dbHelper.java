package com.example.itubeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class dbHelper extends SQLiteOpenHelper {

    public static final String Table_Name="login";
    private static final String  PlaylistTable_Name="PlayList";
    private static final String userName="userName";
    private static final String link="link";
    private static  final String name ="name";
    public dbHelper(Context context) {
        super(context, Table_Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE user(username TEXT primary key,name TEXT,password TEXT)");
        String createPlaylist="CREATE TABLE " +PlaylistTable_Name+" ("+ " ID INTEGER PRIMARY KEY autoincrement , "+userName +" TEXT , "+link+ " TEXT )";
        //db.execSQL(createPlaylist);
        db.execSQL("CREATE TABLE if not exists playList(id integer primary key autoincrement  ,user TEXT ,link TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE if exists user");
        db.execSQL("drop table if exists playList");
    }
    public Boolean insertData(String userName ,String password,String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues vals = new ContentValues();
        vals.put("username", userName);
        vals.put("password", password);
        vals.put("name",name);



        long result=db.insert("user",null,vals);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean insertLink(String userNames,String links){
        SQLiteDatabase DB=getWritableDatabase();
        ContentValues vals=new ContentValues();
        vals.put("user",userNames);
        vals.put("link",links);
        long result=DB.insert("playList",null,vals);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Cursor getPlayList(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select * from playList ",null);
        return cursor;
    }
    public Boolean checkUserName(String userName){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("SELECT * from user where username=?",new String[]{userName});
        if(cursor.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }
    public Boolean checkUserPassword(String userName,String password){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("SELECT * from user where username=? and password=?",new String[] {userName,password});
        if(cursor.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }

}