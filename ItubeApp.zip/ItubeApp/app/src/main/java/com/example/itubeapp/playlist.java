package com.example.itubeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class playlist extends AppCompatActivity {

    ListView listView;
    ArrayList<String> mylist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);


        Intent getintent=getIntent();
        mylist=getintent.getStringArrayListExtra("list");
        listView=findViewById(R.id.listView);
        ListAdapter adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,mylist);
        listView.setAdapter(adapter);
    }
}