package com.example.itubeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class homesPage extends AppCompatActivity {

    EditText url;
    Button playButton,AddToPlaylist,myPlaylist;
    String urlLink;
    dbHelper db;
    String userName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homes_page);

        url=findViewById(R.id.url);
        playButton=findViewById(R.id.Playbutton);
        AddToPlaylist=findViewById(R.id.AddToPlaylist);
        myPlaylist=findViewById(R.id.myPlaylist);

        db=new dbHelper(this);
        Intent getIntent=getIntent();
        userName=getIntent.getStringExtra("userName");



        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(url.getText().toString().equals(null)){
                    Toast.makeText(homesPage.this, "Please enter a valid URL", Toast.LENGTH_SHORT).show();
                }else{
                    urlLink=url.getText().toString();
                    Intent playVid=new Intent(getBaseContext(),homePage.class);
                    playVid.putExtra("url",urlLink);
                    startActivity(playVid);
                }

            }
        });
        AddToPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                urlLink=url.getText().toString();
                Boolean insertData = db.insertLink(userName, urlLink);
                if (insertData) {
                    Toast.makeText(homesPage.this, "Inserted video", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(homesPage.this, "video couldn't be inserted!!", Toast.LENGTH_SHORT).show();
                }
            }

        });
        myPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data=db.getPlayList();
                if(data.getCount()> 0){
                    ArrayList<String> linkList;
                    linkList=addVals(data);
                    //Toast.makeText(homesPage.this, linkList.size(), Toast.LENGTH_SHORT).show();
                    Intent sendList=new Intent(getBaseContext(),playlist.class);
                    sendList.putExtra("list",linkList);
                    startActivity(sendList);

                }
                else{
                    Toast.makeText(homesPage.this, "Data is null", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    private ArrayList<String> addVals(Cursor data){
        String user,link;

        ArrayList<String> finalList=new ArrayList<>();

        while(data.moveToNext()){
            user=data.getString(1);
            link=data.getString(2);
            if(user.equals(userName)){
                String finals="https://www.youtube.com/watch?v="+link;
                finalList.add(finals);
            }

        }
        return finalList;

    }
}