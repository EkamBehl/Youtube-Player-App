package com.example.itubeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpPage extends AppCompatActivity {

    dbHelper db;
    EditText name,username,password,confirmPassword,phone;
    Button SignUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);
        name=findViewById(R.id.signUpName);
        username=findViewById(R.id.signUpUsername);
        password=findViewById(R.id.signUpPassword);
        confirmPassword=findViewById(R.id.signUpConfirmPassword);

        SignUp=findViewById(R.id.createAccount);

        db =new dbHelper(this);


        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String names=name.getText().toString();
                String pass=password.getText().toString();
                String confirPass=confirmPassword.getText().toString();

                String userName=username.getText().toString();
                if(TextUtils.isEmpty(userName) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(confirPass) ){
                    Toast.makeText(SignUpPage.this, "All fields are required!! ", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(pass.equals(confirPass)){
                        Boolean checkUser=db.checkUserName(userName);
                        if(!checkUser){
                            Boolean insertData=db.insertData(userName,pass,names);
                            if(insertData.equals(true)){
                                Toast.makeText(SignUpPage.this, "SignUp successful", Toast.LENGTH_SHORT).show();
                                Intent home=new Intent(SignUpPage.this,MainActivity.class);
                                startActivity(home);
                            }
                            else{
                                Toast.makeText(SignUpPage.this, "SignUp Unsuccessful", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(SignUpPage.this, "User Already exists!!", Toast.LENGTH_SHORT).show();
                        }


                    }
                    else {
                        Toast.makeText(SignUpPage.this, "passwords Don't match!!", Toast.LENGTH_SHORT).show();
                    }

                }


            }
        });
    }
}