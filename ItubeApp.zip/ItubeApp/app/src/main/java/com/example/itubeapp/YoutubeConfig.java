package com.example.itubeapp;

public class YoutubeConfig {
    public YoutubeConfig() {
    }

    private static final String Key_API="AIzaSyBoZkbLWDOJ2HMQBEh09jQRYeBqGCqiJz4";

    public static String getKey_API() {
        return Key_API;
    }
}
